import nltk
from newspaper import Article
from gtts import gTTS

# Download the required NLP tokenizers once at the start
nltk.download('punkt', quiet=True)
nltk.download('punkt_tab', quiet=True)

def text_to_speech(url):
    # 1. Initialize and download the article
    article = Article(url)
    article.download()
    article.parse()
    
    # 2. Run NLP parsing to extract keywords/clean text safely
    article.nlp()
    article_text = article.text
    
    # Quick sanity check: Did we actually get text?
    if not article_text.strip():
        print("Warning: Could not extract text from this URL. The audio might be empty.")
        return

    # 3. Convert the clean text to an MP3
    language = 'en'
    my_obj = gTTS(text=article_text, lang=language, slow=False)
    
    output_filename = "read_article.mp3"
    my_obj.save(output_filename)
    print(f"Success! Audio saved safely to '{output_filename}'")

if __name__ == '__main__':
    text_to_speech(
        url='https://hackr.io/blog/top-tech-companies-hiring-python-developers'
    )
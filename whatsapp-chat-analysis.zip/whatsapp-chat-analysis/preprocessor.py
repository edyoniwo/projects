import re
import pandas as pd

def preprocess(data):
    # Match the pattern at the start of a message line
    pattern = r'\d{1,2}/\d{1,2}/\d{2,4},\s\d{1,2}:\d{2}\s-\s'

    messages = re.split(pattern, data)[1:]
    dates = re.findall(pattern, data)

    min_length = min(len(messages), len(dates))
    messages = messages[:min_length]
    dates = dates[:min_length]

    df = pd.DataFrame({'user_message': messages, 'raw_date': dates})
    
    # Custom absolute extraction bypasses all string format mismatches
    parsed_dates = []
    for raw in df['raw_date']:
        try:
            # Drop the trailing structural characters " - "
            clean_raw = raw.replace(' - ', '').strip()
            # Split into components: ['3/4/20', '15:46']
            date_part, time_part = clean_raw.split(', ')
            # Split date components: ['3', '4', '20']
            m, d, y = date_part.split('/')
            # Handle 2-digit years explicitly (e.g., '20' -> '2020')
            if len(y) == 2:
                y = '20' + y
            # Reconstruct into standard ISO format: '2020-03-04 15:46'
            parsed_dates.append(f"{y}-{m.zfill(2)}-{d.zfill(2)} {time_part}")
        except Exception:
            parsed_dates.append(None)

    df['date'] = pd.to_datetime(parsed_dates, errors='coerce')
    df.drop(columns=['raw_date'], inplace=True)
    df = df.dropna(subset=['date'])

    users = []
    messages_clean = []
    for message in df['user_message']:
        entry = re.split(r'([\w\W]+?):\s', message)
        if entry[1:]:  
            users.append(entry[1])
            messages_clean.append(" ".join(entry[2:]))
        else:
            users.append('group_notification')
            messages_clean.append(entry[0])

    df['user'] = users
    df['message'] = messages_clean
    df.drop(columns=['user_message'], inplace=True)

    df['only_date'] = df['date'].dt.date
    df['year'] = df['date'].dt.year
    df['month_num'] = df['date'].dt.month
    df['month'] = df['date'].dt.month_name()
    df['day'] = df['date'].dt.day
    df['day_name'] = df['date'].dt.day_name()
    df['hour'] = df['date'].dt.hour
    df['minute'] = df['date'].dt.minute

    period = []
    for hour in df['hour']:
        if hour == 23:
            period.append(f"{hour}-00")
        elif hour == 0:
            period.append(f"00-{hour + 1}")
        else:
            period.append(f"{hour}-{hour + 1}")

    df['period'] = period

    return df
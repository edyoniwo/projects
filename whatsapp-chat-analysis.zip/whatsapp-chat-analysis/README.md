WhatsApp Chat Analyzer
An interactive Web Application built using Streamlit to parse, process, and analyze exported WhatsApp chat logs. This tool provides deep data insights into conversation dynamics, participant activity metrics, temporal trends, and textual distributions.
Features
The application processes raw text exports from WhatsApp and generates comprehensive visualization suites split into distinct analytical layers:
1. High-Level Statistics
•	Total Messages: Aggregate count of sent items.
•	Total Words: Total count of textual tokens parsed.
•	Media Shared: Tracks count of media placeholder entries (e.g., images, videos, audio).
•	Links Shared: Extracts and flags hyperlinks shared within text fragments.
2. Temporal & Trend Timelines
•	Monthly Timeline: Interactive trend tracking changes in message frequency month-over-month.
•	Daily Timeline: Micro-level analysis mapping daily messaging volume fluctuations.
3. Behavioral Activity Maps
•	Weekly & Monthly Incline: Identifies the busiest days of the week and months of the year.
•	Interactive Heatmap: A visual density matrix (Day of Week vs. Hour of Day) pinpointing peak operational hours.
4. Group Dynamics (Global Level Only)
•	Most Active Users: Bar charts tracking participant text volume distributions side-by-side with raw pandas tabular dataframes.
5. Textual & Linguistic Analysis
•	WordCloud Generation: Textual frequency visualizations filtering out structural filler content.
•	Most Common Words: Horizontal frequency distributions showing the most repetitive tokens.
•	Emoji Analysis: Comprehensive calculation of usage rates paired with localized distribution pie-charts.
 Project Structure
Plaintext
├── app.py               # Main Streamlit web application interface and layout
├── preprocessor_v2.py   # Regex extraction engine & custom date ISO standardizer
├── helper.py            # Computational backend logic (Stats extraction, NLP, Plotting matrices)
├── setup.sh             # Production environment configuration script for headless servers
└── README.md            # Project documentation (This file)
🔧 Installation & Local Setup
Ensure you have Python 3.8+ installed on your system before proceeding.
1. Clone the Repository
Bash
git clone https://github.com/your-username/whatsapp-chat-analyzer.git
cd whatsapp-chat-analyzer
2. Install Required Dependencies
Install the required analytical and rendering packages:
Bash
pip install streamlit pandas matplotlib seaborn wordcloud emoji
(Note: Ensure you have helper.py in your local directory containing the analytical module definitions needed by app.py).
3. Run the Application
Execute the local Streamlit server runtime instance:
Bash
streamlit run app.py
💡 How To Use The Tool
1.	Open WhatsApp on your device and navigate to the target individual or group chat.
2.	Tap on the menu options settings $\rightarrow$ More $\rightarrow$ Export Chat.
3.	Select Without Media (The tool parses the structural .txt file export).
4.	Launch this application in your browser (http://localhost:8501).
5.	Drag and drop your exported .txt file into the sidebar uploader element.
6.	Select your scope dynamically via the dropdown menu (Overall group analytics or a Specific Individual partition filter).
7.	Click Show Analysis.
⚙️ Core Technical Modules Explained
Data Normalization (preprocessor_v2.py)
Standard regular expression routines handle varying structural layouts. This version implements a hardened format bypass loop:
•	Splits dates using custom split logic, explicitly resolving varying short-form regional structures (e.g., M/D/YY format variants).
•	Appends explicit timestamp paddings (zfill(2)) to reconstruct corrupted text configurations safely into  (YYYY-MM-DD HH:MM) datetime indexes.
Deployment Environment (setup.sh)
Automates creation of Streamlit server configuration presets during containerization procedures (such as deploying to Heroku or Docker environments):
 

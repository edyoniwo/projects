import sys
import subprocess
subprocess.check_call([sys.executable, "-m", "pip", "install", "tensorflow"])

import tensorflow as tf
from tensorflow.keras import layers, models
import numpy as np
import matplotlib.pyplot as plt

# Load and preprocess the dataset
# Using CIFAR-10 which has images of shape (32, 32, 3)
(train_images, _), (_, _) = tf.keras.datasets.cifar10.load_data()

# Normalize images to the range [-1, 1]
train_images = (train_images - 127.5) / 127.5
train_images = train_images.astype('float32')

BUFFER_SIZE = 60000
BATCH_SIZE = 256

# Create batches and shuffle the dataset
train_dataset = tf.data.Dataset.from_tensor_slices(train_images).shuffle(BUFFER_SIZE).batch(BATCH_SIZE)

# Define the generator model (Fixed to output 32x32x3)
def build_generator():
    model = models.Sequential()
    # Start with 8x8 instead of 7x7 to match CIFAR-10 dimensions
    model.add(layers.Dense(8*8*256, use_bias=False, input_shape=(100,)))
    model.add(layers.BatchNormalization())
    model.add(layers.LeakyReLU())
    
    model.add(layers.Reshape((8, 8, 256)))
    
    # Shape: 8x8x128
    model.add(layers.Conv2DTranspose(128, (5, 5), strides=(1, 1), padding='same', use_bias=False))
    model.add(layers.BatchNormalization())
    model.add(layers.LeakyReLU())
    
    # Shape: 16x16x64 (Strides 2x2 doubles height and width)
    model.add(layers.Conv2DTranspose(64, (5, 5), strides=(2, 2), padding='same', use_bias=False))
    model.add(layers.BatchNormalization())
    model.add(layers.LeakyReLU())
    
    # Shape: 32x32x3 (Strides 2x2 doubles it again, matching CIFAR-10 exactly)
    model.add(layers.Conv2DTranspose(3, (5, 5), strides=(2, 2), padding='same', use_bias=False, activation='tanh'))
    return model

# Define the discriminator model
def build_discriminator():
    model = models.Sequential()
    model.add(layers.Conv2D(64, (5, 5), strides=(2, 2), padding='same', input_shape=[32, 32, 3]))
    model.add(layers.LeakyReLU())
    model.add(layers.Dropout(0.3))
    
    model.add(layers.Conv2D(128, (5, 5), strides=(2, 2), padding='same'))
    model.add(layers.LeakyReLU())
    model.add(layers.Dropout(0.3))
    
    model.add(layers.Flatten())
    model.add(layers.Dense(1))
    return model

# Create the generator and discriminator
generator = build_generator()
discriminator = build_discriminator()

# Define the loss and optimizers
cross_entropy = tf.keras.losses.BinaryCrossentropy(from_logits=True)

def generator_loss(fake_output):
    return cross_entropy(tf.ones_like(fake_output), fake_output)

def discriminator_loss(real_output, fake_output):
    real_loss = cross_entropy(tf.ones_like(real_output), real_output)
    fake_loss = cross_entropy(tf.zeros_like(fake_output), fake_output)
    return real_loss + fake_loss

generator_optimizer = tf.keras.optimizers.Adam(1e-4)
discriminator_optimizer = tf.keras.optimizers.Adam(1e-4)

# Training configuration
EPOCHS = 50
noise_dim = 100
num_examples_to_generate = 16

# Constant seed to track progress over epochs
seed = tf.random.normal([num_examples_to_generate, noise_dim])

@tf.function
def train_step(images):
    # Dynamic batch size to handle the smaller final batch of an epoch safely
    current_batch_size = tf.shape(images)[0]
    noise = tf.random.normal([current_batch_size, noise_dim])

    with tf.GradientTape() as gen_tape, tf.GradientTape() as disc_tape:
        generated_images = generator(noise, training=True)

        real_output = discriminator(images, training=True)
        fake_output = discriminator(generated_images, training=True)

        gen_loss = generator_loss(fake_output)
        disc_loss = discriminator_loss(real_output, fake_output)

    gradients_of_generator = gen_tape.gradient(gen_loss, generator.trainable_variables)
    gradients_of_discriminator = disc_tape.gradient(disc_loss, discriminator.trainable_variables)

    generator_optimizer.apply_gradients(zip(gradients_of_generator, generator.trainable_variables))
    discriminator_optimizer.apply_gradients(zip(gradients_of_discriminator, discriminator.trainable_variables))

def train(dataset, epochs):
    for epoch in range(epochs):
        for image_batch in dataset:
            train_step(image_batch)

        # Produce and save images at the end of each epoch
        generate_and_save_images(generator, epoch + 1, seed)
        print(f'Epoch {epoch+1} completed')

def generate_and_save_images(model, epoch, test_input):
    predictions = model(test_input, training=False)

    fig = plt.figure(figsize=(4, 4))

    for i in range(predictions.shape[0]):
        plt.subplot(4, 4, i+1)
        # Denormalize from [-1, 1] back to [0, 1] for matplotlib plotting
        plt.imshow((predictions[i] + 1) / 2)
        plt.axis('off')

    plt.savefig(f'image_at_epoch_{epoch:04d}.png')
    plt.show()

# Start the training process
if __name__ == '__main__':
    train(train_dataset, EPOCHS)
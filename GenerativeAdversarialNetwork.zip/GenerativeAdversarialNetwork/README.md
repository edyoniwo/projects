This repository contains a Deep Convolutional Generative Adversarial Network (DCGAN) implemented in TensorFlow and Keras. The model is specifically tailored to train on the CIFAR-10 dataset, generating synthetic $32 \times 32 \times 3$ color images from random noise vectors.

Architecture Overview
The project implements a classic minimax adversarial game between two deep neural networks: a Generator and a Discriminator.

Generator Architecture

The Generator takes a 100-dimensional random noise vector (latent space) and upsamples it into a 32 X 32 X 32 pixel image. It uses Conv2DTranspose (fractionally-strided convolutions) to scale the feature maps.

Input: Random Noise Vector $\in \mathbb{R}^{100}$
Dense Layer & Reshape: Project to 8 X8 X 256
Transpose Convolution 1: Strides (1,1) $\rightarrow$ Outputs $8 X 8 X 128$
Transpose Convolution 2: Strides (2,2) $\rightarrow$ Outputs $16 X 16 X 64$
Transpose Convolution 3: Strides (2,2) with tanh activation $\rightarrow$ Outputs $32 X 32 X 3$
Normalization: BatchNormalization and LeakyReLU activations are applied throughout the intermediate layers to stabilize training.

Discriminator Architecture
The Discriminator acts as a binary classifier that evaluates an image (either a real one from CIFAR-10 or a fake one from the Generator) and outputs a scalar logit score representing the probability of the image being real.

Input: Image shape $(32, 32, 3)$
Convolution 1: Strides (2,2), 64 filters $\rightarrow$ Outputs 16 X 16 X 64
Convolution 2: Strides (2,2), 128 filters $\rightarrow$ Outputs 8 X 8 X 128
Output Layer: Flattened to a single scalar unit (logit output).
Regularization: Utilizes LeakyReLU activations and Dropout(0.3) to prevent the discriminator from overpowering the generator early in training.

Installation & Setup

Prerequisites
Python 3.8+
Pip package manager

The script is self-contained and automatically handles the installation of tensorflow if it isn't already present in your environment via subprocess. However, ensuring your environment is ready is recommended:

# Clone the repository
git clone https://github.com/your-username/cifar10-dcgan.git
cd cifar10-dcgan

# Optional: Set up a virtual environment
python -m venv venv
source venv/bin/activate  # On Windows use `venv\Scripts\activate`

Usage
To start training the DCGAN, run the main Python script:

python edward.py

What happens during execution:

Dependency Check: The script checks for and installs TensorFlow if required.
Dataset Acquisition: Automatically downloads the CIFAR-10 dataset via Keras Utilities.
Data Pipeline: Normalizes image pixel values from $[0, 255]$ to the range $[-1, 1]$ to match the generator's tanh output layer. It then caches, shuffles, and batches the dataset ($256$ batch size).
Adversarial Training Loop: Runs for 50 epochs by default.
Artifact Generation: At the end of every epoch, a 4 X 4 grid of generated sample images is plotted and saved to disk as image_at_epoch_XXXX.png to monitor qualitative progression.

Hyperparameters & Loss Function

Loss Function: Binary Cross-Entropy with Logits (from_logits=True).
Optimizers: Adam optimizer for both networks with a learning rate of $1\times10^{-4}$.
Latent Dimension: 100 (Gaussian Noise).
Batch Size: 256 (With dynamic batch size handling implemented inside @tf.function to prevent errors on the final, smaller partial batch).

Project structure
├── edward.py           * Main application script containing the full pipeline and training loop
├── build_generator.py  * Standalone/reference module detailing the Generator network logic
└── README.md           
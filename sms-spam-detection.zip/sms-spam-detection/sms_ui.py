import streamlit as st
import joblib

st.set_page_config(page_title="SMS Spam Shield", page_icon="🔒", layout="centered")

st.title("🔒 SMS Spam Detection Engine")
st.write("Type or paste an incoming SMS message below to check if it's safe or spam.")

@st.cache_resource
def load_artifacts():
    model = joblib.load('sms_spam_model.pkl')
    vectorizer = joblib.load('tfidf_vectorizer.pkl')
    classes = joblib.load('label_classes.pkl')
    return model, vectorizer, classes

try:
    model, vectorizer, classes = load_artifacts()
    
    user_message = st.text_area("SMS Message Text:", placeholder="Enter text here...", height=150)
    
    if st.button("Analyze Message", type="primary"):
        if not user_message.strip():
            st.warning("Please enter some text to analyze.")
        else:
            # Transformed text processed as sparse matrix
            vectorized_text = vectorizer.transform([user_message])
            prediction_idx = model.predict(vectorized_text)[0]
            prediction_label = classes[prediction_idx] # Maps index back to 'ham' or 'spam'
            
            st.markdown("---")
            
            # Safeguard against models that don't support probability calculations
            if hasattr(model, "predict_proba"):
                probabilities = model.predict_proba(vectorized_text)[0]
                confidence = f" (Confidence: {probabilities[prediction_idx]:.2%})"
            else:
                confidence = ""

            if prediction_label == 'spam':
                st.error(f"🚨 **Spam Detected!**{confidence}")
                st.markdown("⚠️ *Recommendation: Do not click any links or reply to this message.*")
            else:
                st.success(f"✅ **Safe / Legitimate Message**{confidence}")

except FileNotFoundError:
    st.error("Missing model artifacts! Please execute your backend training pipeline script first.")
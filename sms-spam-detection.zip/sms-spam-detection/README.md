SMS Spam Classifier - Model Benchmarking & Training

This repository contains two Python scripts designed to clean text data, extract features using TF-IDF, and benchmark multiple machine learning algorithms to classify SMS messages as either Spam or Ham (Legitimate).
Both scripts utilize the classic SMS Spam Collection dataset (spam.csv) but approach memory handling, model evaluation, and artifact saving differently.

While both scripts share the same preprocessing core, they diverge during feature extraction and model export:
1. app.py (Production & Memory Optimized)
Memory Efficiency: Keeps the TF-IDF feature matrix X as a sparse matrix. This is highly recommended for text data to avoid exploding memory consumption.

Dynamic Model Selection: Automatically benchmarks Naive Bayes, Logistic Regression, and Random Forest, then dynamically selects and exports the best performing model based on Precision (crucial for spam detection to minimize false positives).

UI Mapping Readiness: Saves label_classes.pkl alongside the model and vectorizer to ensure the frontend application accurately maps the encoded integers back to the original text labels.

app2.py (Analysis & Visualization Oriented)
Dense Matrix Conversion: Converts the TF-IDF matrix into a dense array using .toarray(). Note: This can cause high memory overhead on larger datasets.

Tabular Evaluation: Aggregates all model metrics into a structured Pandas DataFrame for clean, tabular logging.

Static Export: Statically saves the Naive Bayes model by default, rather than picking the top performer dynamically.

Architecture & Workflow

                    │
                    ▼
       Label Encoding & TF-IDF Vectorization
                    │
                    ▼
         Train/Test Split (80/20)
                    │
       ┌────────────┼────────────┐
       ▼            ▼            ▼
 [Naive Bayes] [Logistic Reg] [Random Forest]
       │            │            │
       └────────────┼────────────┘
                    ▼
         Evaluate Metrics & Export (.pkl)

Getting Started
1. Prerequisites & InstallationEnsure you have Python 3.8+ installed. Install the required dependencies using pip:

Bashpip install numpy pandas scikit-learn joblib seaborn matplotlib

2. Dataset Setup
Place your spam.csv dataset in the root directory of the project. The script is configured to look for a file named spam.csv encoded in cp1252 with columns v1 (target) and v2 (text).3

3. Running the ScriptsTo run the optimized production version with dynamic best-model selection:
Bash python app.py

To run the tabular analysis version:Bashpython app2.py
 Evaluation MetricsThe scripts evaluate models based on two key metrics:Accuracy: The overall percentage of correctly predicted messages.Precision: The ratio of true spam messages among all messages predicted as spam.
  Why Precision Matters: In spam filtering, high precision is vital. A false positive means a legitimate, potentially important text (Ham) gets wrongly moved to the Spam folder.
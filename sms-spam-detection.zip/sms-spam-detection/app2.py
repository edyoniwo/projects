import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import joblib
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score

def load_and_clean_data(filepath: str) -> pd.DataFrame:
    """Loads dataset, drops unused columns, handles duplicates and renames features."""
    df = pd.read_csv(filepath, encoding='cp1252')
    columns_to_drop = ['Unnamed: 2', 'Unnamed: 3', 'Unnamed: 4']
    df.drop(columns=columns_to_drop, inplace=True, errors='ignore')
    df.rename(columns={'v1': 'target', 'v2': 'text'}, inplace=True)
    if df.duplicated().sum() > 0:
        df.drop_duplicates(keep='first', inplace=True)
        df.reset_index(drop=True, inplace=True)
    return df

def train_and_evaluate(df: pd.DataFrame):
    """Encodes labels, vectorizes text, runs benchmarks, and saves the top pipeline."""
    encoder = LabelEncoder()
    df['target'] = encoder.fit_transform(df['target'])
    
    tfidf = TfidfVectorizer(stop_words='english', max_features=3000)
    X = tfidf.fit_transform(df['text']).toarray()
    y = df['target'].values
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    models = {
        'Naive Bayes': MultinomialNB(),
        'Logistic Regression': LogisticRegression(),
        'Random Forest': RandomForestClassifier(random_state=42)
    }
    
    performance = {'Algorithm': [], 'Accuracy': [], 'Precision': []}
    
    for name, model in models.items():
        model.fit(X_train, y_train)
        preds = model.predict(X_test)
        performance['Algorithm'].append(name)
        performance['Accuracy'].append(accuracy_score(y_test, preds))
        performance['Precision'].append(precision_score(y_test, preds))
        
    performance_df = pd.DataFrame(performance)
    print("\n--- Model Benchmark Results ---")
    print(performance_df)
    
    # Save the files for the app.py wrapper to use
    joblib.dump(models['Naive Bayes'], 'sms_spam_model.pkl')
    joblib.dump(tfidf, 'tfidf_vectorizer.pkl')
    print("\nModel artifacts saved successfully as '.pkl' files.")

if __name__ == "__main__":
    data_path = 'spam.csv'
    try:
        cleaned_df = load_and_clean_data(data_path)
        train_and_evaluate(cleaned_df)
    except FileNotFoundError:
        print(f"Error: Could not find the dataset file at '{data_path}'.")
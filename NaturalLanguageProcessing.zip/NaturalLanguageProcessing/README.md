IMDB Movie Review Sentiment Analysis using RNN (LSTM)
This repository contains a Natural Language Processing (NLP) pipeline and deep learning model built using TensorFlow and Keras to perform binary sentiment classification on movie reviews. The architecture leverages an Embedding layer followed by a Long Short-Term Memory (LSTM) recurrent network to capture sequential patterns and contextual dependencies in text data.
 Model Architecture Overview
The neural network is structured sequentially to process text sequences and output a probability score indicating whether a review's sentiment is positive or negative.
1. Layer Breakdown
•	Embedding Layer: Maps the sparse, integer-encoded words into a continuous, dense vector space. It handles a vocabulary size ($input\_dim$) of 10,000 words and projects each token into a 128-dimensional embedding space ($output\_dim$).
•	LSTM Layer: A recurrent layer containing 128 memory cells. LSTMs mitigate the vanishing gradient problem inherent in traditional RNNs by using gating mechanisms (input, forget, and output gates), allowing the model to preserve long-term historical dependencies across a maximum sequence length of 200 words.
•	Dense Output Layer: A single fully-connected neuron utilizing a sigmoid activation function. It squashes the final hidden state vector into a probability range of $[0, 1]$, where values closer to 1 signify positive sentiment and values closer to 0 signify negative sentiment.
 Dataset & Text Preprocessing
The project utilizes the benchmark IMDB Movie Reviews Dataset natively sourced through Keras datasets.
•	Vocabulary Constraint: Only the top 10,000 most frequently occurring words in the dataset are loaded to maintain a controlled vocabulary matrix and suppress rare noise words.
•	Sequence Padding: Because movie reviews vary in length, sequences are normalized via pad_sequences. Reviews longer than 200 words are truncated, and shorter reviews are pre-padded with zeros to ensure a uniform tensor input shape of (batch_size, 200).
 Installation & Setup
Prerequisites
•	Python 3.8+
•	TensorFlow 2.x
Set up your workspace environment using the following steps:
Bash
# Clone the repository
git clone https://github.com/your-username/imdb-sentiment-lstm.git
cd imdb-sentiment-lstm

# Set up a virtual environment (Recommended)
python -m venv venv
source venv/bin/activate  # On Windows use `venv\Scripts\activate`

# Install required packages
pip install tensorflow numpy
 Usage
To execute the data preprocessing, model compilation, training, and final evaluation, run the main python script:
Bash
python edwards.py
Execution Pipeline Detail:
1.	Data Loading: Automatically downloads and partitions the dataset into training and testing splits.
2.	Padding: Scales the sequence dimensions.
3.	Compilation: Compiles using the adam optimization algorithm and tracking metrics via accuracy. The loss function used is binary_crossentropy, which is standard for binary classification tasks.
4.	Training Loop: Trains for 5 epochs with a batch size of 32. 20% of the training data is automatically held out for validation monitoring (validation_split=0.2) to track performance and prevent overfitting.
5.	Evaluation: Evaluates the generalized performance against unseen test data and logs the accuracy metric to the console.*

📉 Hyperparameters Summary
Hyperparameter	Configuration Value
Vocabulary Size (num_words)	10,000
Max Sequence Length (maxlen)	200
Embedding Dimensions	128
LSTM Hidden Units	128
Optimizer	Adam
Loss Function	Binary Crossentropy
Batch Size	32
Epochs	5

Project Structure

├── edwards.py        # Complete pipeline file containing preprocessing, network architecture, and training
└── README.md         # Project documentation

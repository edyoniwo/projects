import tensorflow as tf
from tensorflow.keras import layers, models
from tensorflow.keras.datasets import imdb
from tensorflow.keras.preprocessing.sequence import pad_sequences

# Load and preprocess the IMDB dataset
num_words = 10000  # Only consider the top 10,000 words in the dataset
maxlen = 200  # Only consider the first 200 words of each review

(train_data, train_labels), (test_data, test_labels) = imdb.load_data(num_words=num_words)

# Pad sequences to ensure uniform input length
train_data = pad_sequences(train_data, maxlen=maxlen)
test_data = pad_sequences(test_data, maxlen=maxlen)

# Define the RNN model architecture
def create_rnn_model(input_shape):
    model = models.Sequential()
    model.add(layers.Embedding(input_dim=num_words, output_dim=128, input_length=maxlen))
    model.add(layers.LSTM(128, return_sequences=False))
    model.add(layers.Dense(1, activation='sigmoid'))
    return model

# Create the model
model = create_rnn_model((maxlen,))

# Compile the model
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

# Train the model
history = model.fit(train_data, train_labels, epochs=5, batch_size=32, validation_split=0.2)

# Evaluate the model
test_loss, test_acc = model.evaluate(test_data, test_labels)
print(f'Test Accuracy: {test_acc:.2f}')